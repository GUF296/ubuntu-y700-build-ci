/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (C) 2019, Raspberry Pi Ltd
 *
 * ISP control algorithms
 */

#include "algorithm.h"

using namespace RPiController;

int Algorithm::read([[maybe_unused]] const libcamera::ValueNode &params)
{
	return 0;
}

void Algorithm::initialise()
{
}

void Algorithm::switchMode([[maybe_unused]] CameraMode const &cameraMode,
			   [[maybe_unused]] Metadata *metadata)
{
}

void Algorithm::prepare([[maybe_unused]] Metadata *imageMetadata)
{
}

void Algorithm::process([[maybe_unused]] StatisticsPtr &stats,
			[[maybe_unused]] Metadata *imageMetadata)
{
}

/* For registering algorithms with the system: */

namespace {

std::map<std::string, AlgoCreateFunc> &algorithms()
{
	static std::map<std::string, AlgoCreateFunc> algorithms;
	return algorithms;
}

} /* namespace */

std::map<std::string, AlgoCreateFunc> const &RPiController::getAlgorithms()
{
	return algorithms();
}

RegisterAlgorithm::RegisterAlgorithm(char const *name,
				     AlgoCreateFunc createFunc)
{
	algorithms()[std::string(name)] = createFunc;
}
