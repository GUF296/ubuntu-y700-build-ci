/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * Copyright (C) 2019, Google Inc.
 *
 * Cam application
 */

#pragma once

enum {
	OptCamera = 'c',
	OptCapture = 'C',
	OptDisplay = 'D',
	OptFile = 'F',
	OptHelp = 'h',
	OptInfo = 'I',
	OptList = 'l',
	OptListProperties = 'p',
	OptMonitor = 'm',
	OptOrientation = 'o',
	OptSDL = 'S',
	OptStream = 's',
	OptVersion = 'v',
	OptListControls = 256,
	OptStrictFormats = 257,
	OptMetadata = 258,
	OptCaptureScript = 259,
};
