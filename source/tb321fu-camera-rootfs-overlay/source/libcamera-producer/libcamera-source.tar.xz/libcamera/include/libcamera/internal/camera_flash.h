/* SPDX-License-Identifier: LGPL-2.1-or-later */
/*
 * V4L2 flash controller helper.
 */

#pragma once

#include <memory>
#include <stdint.h>
#include <string>

#include <libcamera/base/class.h>
#include <libcamera/base/log.h>

#include <libcamera/controls.h>

namespace libcamera {

class MediaEntity;
class V4L2Subdevice;

class CameraFlash : protected Loggable
{
public:
	explicit CameraFlash(const MediaEntity *entity);
	~CameraFlash();

	int init();

	const std::string &model() const { return model_; }
	const ControlInfoMap &controls() const;

	int setOff();
	int setTorch(int32_t intensity);
	int strobe(int32_t intensity, int32_t timeout);
	int stopStrobe();
	int faults() const;

protected:
	std::string logPrefix() const override;

private:
	LIBCAMERA_DISABLE_COPY_AND_MOVE(CameraFlash)

	int validateFlashDriver();

	const MediaEntity *entity_;
	std::unique_ptr<V4L2Subdevice> subdev_;

	std::string model_;
};

} /* namespace libcamera */
